
from datetime import datetime
from decimal import Decimal, InvalidOperation

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.models import Company, Job
from backend.app.services.jobicy import fetch_jobs
from backend.app.services.freehire import fetch_jobs as fetch_freehire_jobs

def parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None

    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))

        # Keep timestamps timezone-aware for PostgreSQL.
        if parsed.tzinfo is None:
            from datetime import timezone
            parsed = parsed.replace(tzinfo=timezone.utc)

        return parsed
    except (ValueError, TypeError):
        return None


def parse_decimal(value) -> Decimal | None:
    if value is None or value == "":
        return None

    try:
        return Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None


def normalize_job(raw: dict) -> dict | None:
    source_id = raw.get("id")
    title = raw.get("jobTitle")
    job_url = raw.get("url")
    company_name = raw.get("companyName")

    # These fields are required by our Job model.
    if not source_id or not title or not job_url:
        return None

    job_types = raw.get("jobType") or []
    industries = raw.get("jobIndustry") or []

    if isinstance(job_types, str):
        job_types = [job_types]

    if isinstance(industries, str):
        industries = [industries]

    location = raw.get("jobGeo")

    return {
        "source_job_id": str(source_id),
        "title": str(title)[:255],
        "description": (
            raw.get("jobDescription")
            or raw.get("jobExcerpt")
        ),
        "location": str(location)[:255] if location else None,
        "remote_type": (
            "remote"
            if str(location or "").strip().lower() == "anywhere"
            else "remote"
        ),
        "employment_type": ", ".join(map(str, job_types))[:50] or None,
        "experience_level": str(raw["jobLevel"])[:100]
        if raw.get("jobLevel")
        else None,
        "salary_min": parse_decimal(raw.get("salaryMin")),
        "salary_max": parse_decimal(raw.get("salaryMax")),
        "salary_currency": str(raw["salaryCurrency"])[:3].upper()
        if raw.get("salaryCurrency")
        else None,
        "job_url": str(job_url),
        "source": "jobicy",
        "posted_at": parse_datetime(raw.get("pubDate")),
        "source_metadata": {
            "company_name": company_name,
            "company_logo": raw.get("companyLogo"),
            "job_industry": industries,
            "salary_period": raw.get("salaryPeriod"),
            "job_slug": raw.get("jobSlug"),
        },
    }


def normalize_freehire_job(raw: dict) -> dict | None:
    source_id = raw.get("public_slug") or raw.get("external_id")
    title = raw.get("title")
    job_url = raw.get("url")

    if not source_id or not title or not job_url:
        return None

    # Don't import jobs explicitly marked as closed.
    if raw.get("closed_at"):
        return None

    company_name = raw.get("company")
    location = raw.get("location")
    enrichment = raw.get("enrichment") or {}

    countries = raw.get("countries") or []
    skills = raw.get("skills") or []
    reality = raw.get("reality") or {}

    if isinstance(countries, str):
        countries = [countries]

    if isinstance(skills, str):
        skills = [skills]

    return {
        "source_job_id": str(source_id),
        "title": str(title).strip()[:255],
        "description": raw.get("description") or enrichment.get("summary"),
        "location": str(location).strip()[:255] if location else None,
        # Don't guess work mode when the source doesn't provide it.
        "remote_type": raw.get("work_mode"),
        "employment_type": raw.get("employment_type"),
        "experience_level": raw.get("experience_level"),
        "salary_min": parse_decimal(raw.get("salary_min")),
        "salary_max": parse_decimal(raw.get("salary_max")),
        "salary_currency": (
            str(raw["salary_currency"])[:3].upper()
            if raw.get("salary_currency")
            else None
        ),
        "job_url": str(job_url),
        "source": "freehire",
        "posted_at": parse_datetime(raw.get("posted_at")),
        "source_metadata": {
            "company_name": company_name,
            "provider_source": raw.get("source"),
            "company_slug": raw.get("company_slug"),
            "countries": countries,
            "skills": skills,
            "posting_language": enrichment.get("posting_language"),
            "reality": reality,
        },
    }


async def save_normalized_jobs(
    db: AsyncSession,
    normalized_jobs: list[dict],
    source: str,
    fetched_count: int,
) -> dict:
    source_ids = [job["source_job_id"] for job in normalized_jobs]

    created = 0
    skipped = fetched_count - len(normalized_jobs)

    try:
        existing_ids: set[str] = set()

        if source_ids:
            existing_result = await db.execute(
                select(Job.source_job_id).where(
                    Job.source == source,
                    Job.source_job_id.in_(source_ids),
                )
            )
            existing_ids = {
                str(source_id)
                for source_id in existing_result.scalars().all()
            }

        company_cache: dict[str, Company] = {}

        for job_data in normalized_jobs:
            source_id = str(job_data["source_job_id"])

            if source_id in existing_ids:
                skipped += 1
                continue

            company_name = (
                job_data.get("source_metadata", {}).get("company_name")
            )
            company_id = None

            if company_name and company_name.strip():
                company_key = company_name.strip().casefold()

                if company_key not in company_cache:
                    result = await db.execute(
                        select(Company).where(
                            func.lower(Company.name) == company_key
                        ).limit(1)
                    )
                    company = result.scalar_one_or_none()

                    if company is None:
                        company = Company(name=company_name.strip())
                        db.add(company)
                        await db.flush()

                    company_cache[company_key] = company

                company_id = company_cache[company_key].id

            job_payload = {
                **job_data,
                "source": source,
                "source_job_id": source_id,
                "company_id": company_id,
            }

            db.add(Job(**job_payload))
            existing_ids.add(source_id)
            created += 1

        await db.commit()

    except Exception:
        await db.rollback()
        raise

    return {
        "source": source,
        "fetched": fetched_count,
        "created": created,
        "skipped": skipped,
    }


async def discover_and_save_jobs(
    db: AsyncSession,
    count: int = 20,
    tag: str | None = None,
) -> dict:
    raw_jobs = await fetch_jobs(count=count, tag=tag)

    normalized_jobs = [
        job
        for raw in raw_jobs
        if (job := normalize_job(raw)) is not None
    ]

    return await save_normalized_jobs(
        db=db,
        normalized_jobs=normalized_jobs,
        source="jobicy",
        fetched_count=len(raw_jobs),
    )


async def discover_and_save_freehire_jobs(
    db: AsyncSession,
    query: str = "Laravel PHP Python",
    count: int = 20,
    country: str | None = "IN",
    work_mode: str | None = None,
) -> dict:
    raw_jobs = await fetch_freehire_jobs(
        query=query,
        count=count,
        country=country,
        work_mode=work_mode,
    )

    normalized_jobs = [
        job
        for raw in raw_jobs
        if (job := normalize_freehire_job(raw)) is not None
    ]

    return await save_normalized_jobs(
        db=db,
        normalized_jobs=normalized_jobs,
        source="freehire",
        fetched_count=len(raw_jobs),
    )

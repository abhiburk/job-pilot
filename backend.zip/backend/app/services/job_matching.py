
import re
from decimal import Decimal
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.models import Candidate, CandidateSkill, Job, JobMatch, Skill


MODEL_VERSION = "rules-v2"

KNOWN_SKILLS = [
    "Laravel", "PHP", "Python", "FastAPI", "Django",
    "JavaScript", "TypeScript", "React", "Vue", "Node.js",
    "PostgreSQL", "MySQL", "SQL", "Redis", "RabbitMQ",
    "Docker", "Kubernetes", "AWS", "Git", "CI/CD",
    "REST API", "Microservices", "System Design",
    "LLM", "RAG", "Machine Learning",
]


def contains_term(text: str, term: str) -> bool:
    pattern = rf"(?<!\w){re.escape(term)}(?!\w)"
    return re.search(pattern, text, re.IGNORECASE) is not None


def extract_skills(text: str) -> set[str]:
    return {
        skill
        for skill in KNOWN_SKILLS
        if contains_term(text, skill)
    }


def normalize(value: str | None) -> str:
    return (value or "").strip().casefold()


def calculate_experience_score(
    candidate_years: Decimal | None,
    experience_level: str | None,
) -> Decimal | None:
    if candidate_years is None or not experience_level:
        return None

    level = experience_level.casefold()
    years = float(candidate_years)

    if any(term in level for term in ("senior", "lead", "principal")):
        score = 100 if years >= 5 else 60 if years >= 3 else 30
    elif any(term in level for term in ("mid", "intermediate")):
        score = 100 if 2 <= years <= 6 else 70 if years > 6 else 50
    elif any(term in level for term in ("junior", "entry", "graduate")):
        score = 100 if years <= 3 else 75
    else:
        return None

    return Decimal(str(score))


def calculate_preference_score(
    candidate: Candidate,
    job: Job,
) -> Decimal | None:
    scores: list[float] = []

    # Job-title preference
    titles = candidate.preferred_job_titles or []
    if titles:
        job_title = normalize(job.title)
        title_matches = [
            title for title in titles
            if normalize(title) and (
                normalize(title) in job_title
                or job_title in normalize(title)
            )
        ]
        scores.append(100.0 if title_matches else 0.0)

    # Work-mode preference
    work_modes = [
        normalize(mode) for mode in (candidate.preferred_work_modes or [])
    ]
    if work_modes and job.remote_type:
        remote_type = normalize(job.remote_type)
        remote_match = any(
            mode in remote_type or remote_type in mode
            for mode in work_modes
        )
        scores.append(100.0 if remote_match else 0.0)

    # Location preference
    locations = [
        normalize(location)
        for location in (candidate.preferred_locations or [])
        if normalize(location)
    ]
    if locations and job.location:
        job_location = normalize(job.location)
        location_match = any(
            location in job_location or job_location in location
            for location in locations
        )
        scores.append(100.0 if location_match else 0.0)

    if not scores:
        return None

    return Decimal(str(round(sum(scores) / len(scores), 2)))


def calculate_salary_score(
    candidate_minimum: Decimal | None,
    job_minimum: Decimal | None,
    job_maximum: Decimal | None,
    candidate_currency: str | None,
    job_currency: str | None,
) -> Decimal | None:
    if candidate_minimum is None or (
        job_minimum is None and job_maximum is None
    ):
        return None

    # Don't compare monetary values in different currencies.
    if (
        candidate_currency
        and job_currency
        and candidate_currency.casefold() != job_currency.casefold()
    ):
        return None

    if job_maximum is not None and job_maximum >= candidate_minimum:
        return Decimal("100.00")

    if job_minimum is not None and job_minimum >= candidate_minimum:
        return Decimal("100.00")

    return Decimal("0.00")

def weighted_score(
    components: dict[str, Decimal | None],
) -> Decimal:
    weights = {
        "role_relevance": 20,
        "skills": 40,
        "experience": 15,
        "preferences": 15,
        "salary": 10,
    }

    weighted_total = sum(
        (components.get(name) if components.get(name) is not None
         else Decimal("50")) * weight
        for name, weight in weights.items()
    )

    return (weighted_total / Decimal("100")).quantize(
        Decimal("0.01")
    )


def build_match_explanation(
    score: Decimal,
    title_skills: set[str],
    description_skills: set[str],
    candidate_skills: set[str],
    matched: list[str],
    gaps: list[str],
    preference_score: Decimal | None,
    experience_score: Decimal | None,
    salary_score: Decimal | None,
) -> str:
    matched_count = len(matched)
    missing_count = len(gaps)

    if score >= Decimal("80"):
        match_summary = "Strong match"
    elif score >= Decimal("60"):
        match_summary = "Good match"
    elif score >= Decimal("40"):
        match_summary = "Partial match"
    else:
        match_summary = "Low match"

    parts = [f"{match_summary}: {score}/100."]

    if title_skills:
        matched_title_skills = candidate_skills & title_skills
        parts.append(
            f"Matched {len(matched_title_skills)} of "
            f"{len(title_skills)} recognized skills in the job title."
        )
    elif description_skills:
        parts.append(
            "No recognized skills were found in the job title; "
            "the skills assessment relies on the description."
        )
    else:
        parts.append(
            "No recognized technical skills were identified "
            "in the job title or description."
        )

    if matched_count:
        parts.append(f"Matching skills: {', '.join(matched[:8])}.")

    if missing_count:
        parts.append(
            f"Skills not found in your profile: "
            f"{', '.join(gaps[:8])}."
        )

    if preference_score is not None and preference_score >= Decimal("100"):
        parts.append("The role matches at least one saved job preference.")

    if experience_score is None:
        parts.append("Experience fit could not be fully assessed.")

    if salary_score is None:
        parts.append("Salary fit could not be assessed from the available data.")

    parts.append(
        "This is a rule-based estimate. Requirements may be missing "
        "or unrecognized, and skills absent from your profile may "
        "still be skills you possess."
    )

    return " ".join(parts)


async def match_jobs(
    db: AsyncSession,
    candidate_id: UUID,
) -> dict:
    candidate = await db.get(Candidate, candidate_id)

    if candidate is None:
        raise ValueError("Candidate not found")

    skill_result = await db.execute(
        select(Skill.name)
        .join(CandidateSkill, CandidateSkill.skill_id == Skill.id)
        .where(CandidateSkill.candidate_id == candidate_id)
    )
    candidate_skills = {
        name for name in skill_result.scalars().all()
    }

    profile_text = " ".join(filter(None, [
        candidate.headline,
        candidate.summary,
        candidate.resume_text,
    ]))
    candidate_skills |= extract_skills(profile_text)

    job_result = await db.execute(
        select(Job).where(Job.is_active.is_(True))
    )
    jobs = job_result.scalars().all()

    processed = 0

    try:
        for job in jobs:
            
            title_skills = extract_skills(job.title or "")
            description_skills = extract_skills(job.description or "")

            job_skills = title_skills | description_skills
            matched = sorted(candidate_skills & job_skills)
            gaps = sorted(job_skills - candidate_skills)

            skills_score = None

            if title_skills or description_skills:
                title_score = (
                    len(candidate_skills & title_skills) / len(title_skills)
                    if title_skills else None
                )

                description_score = (
                    len(candidate_skills & description_skills)
                    / len(description_skills)
                    if description_skills else None
                )

                if title_score is not None and description_score is not None:
                    raw_score = 0.7 * title_score + 0.3 * description_score
                elif title_score is not None:
                    raw_score = title_score
                else:
                    raw_score = description_score

                skills_score = Decimal(str(round(raw_score * 100, 2)))

                # A single description-only skill isn't sufficient evidence
                # for a strong skills match.
                if not title_skills and len(description_skills) == 1:
                    skills_score = min(skills_score, Decimal("40.00"))

            experience_score = calculate_experience_score(
                candidate.years_experience,
                job.experience_level,
            )

            preference_score = calculate_preference_score(
                candidate,
                job,
            )

            salary_score = calculate_salary_score(
                candidate.minimum_salary,
                job.salary_min,
                job.salary_max,
                candidate.salary_currency,
                job.salary_currency,
            )

            role_relevance_score = calculate_role_relevance_score(
                job=job,
                candidate=candidate,
            )

            score = weighted_score({
                "role_relevance": role_relevance_score,
                "skills": skills_score,
                "experience": experience_score,
                "preferences": preference_score,
                "salary": salary_score,
            })

            if role_relevance_score == Decimal("0.00"):
                score = min(score, Decimal("20.00"))

            strengths = [
                f"Matching skill: {skill}" for skill in matched
            ]
            if preference_score is not None and preference_score >= 100:
                strengths.append("Matches at least one saved job preference")

            
            explanation = build_match_explanation(
                score=score,
                title_skills=title_skills,
                description_skills=description_skills,
                candidate_skills=candidate_skills,
                matched=matched,
                gaps=gaps,
                preference_score=preference_score,
                experience_score=experience_score,
                salary_score=salary_score,
            )

            statement = insert(JobMatch).values(
                candidate_id=candidate_id,
                job_id=job.id,
                score=score,
                role_relevance_score=role_relevance_score,
                skills_score=skills_score,
                experience_score=experience_score,
                preference_score=preference_score,
                salary_score=salary_score,
                strengths=strengths,
                gaps=gaps,
                explanation=explanation,
                model_version=MODEL_VERSION,
            )

            statement = statement.on_conflict_do_update(
                constraint="uq_candidate_job_match",
                set_={
                    "score": statement.excluded.score,
                    "skills_score": statement.excluded.skills_score,
                    "experience_score": statement.excluded.experience_score,
                    "preference_score": statement.excluded.preference_score,
                    "role_relevance_score": statement.excluded.role_relevance_score,
                    "salary_score": statement.excluded.salary_score,    
                    "strengths": statement.excluded.strengths,
                    "gaps": statement.excluded.gaps,
                    "explanation": statement.excluded.explanation,
                    "model_version": statement.excluded.model_version,
                },
            )

            await db.execute(statement)
            processed += 1

        await db.commit()

    except Exception:
        await db.rollback()
        raise

    return {
        "candidate_id": str(candidate_id),
        "jobs_processed": processed,
        "model_version": MODEL_VERSION,
    }



def calculate_role_relevance_score(
    job: Job,
    candidate: Candidate,
) -> Decimal:
    title = normalize(job.title or "")

    # Normalize punctuation so "Full-Stack" and "Full Stack"
    # are treated consistently.
    normalized_title = re.sub(r"[^a-z0-9+#]+", " ", title).strip()

    preferred_titles = [
        re.sub(r"[^a-z0-9+#]+", " ", normalize(item)).strip()
        for item in (candidate.preferred_job_titles or [])
        if normalize(item)
    ]

    # Strong match for a saved preferred title.
    if any(
        preferred in normalized_title
        for preferred in preferred_titles
    ):
        return Decimal("100.00")

    profile_text = " ".join(filter(None, [
        candidate.headline,
        candidate.summary,
        candidate.resume_text,
    ]))
    candidate_skills = extract_skills(profile_text)
    title_skills = extract_skills(job.title or "")

    # A relevant technology explicitly named in the job title
    # is a strong signal.
    if candidate_skills & title_skills:
        return Decimal("95.00")

    # Related role families, ranked by relevance to this profile.
    if any(term in normalized_title for term in (
        "backend", "back end", "php developer",
        "laravel developer", "full stack", "fullstack",
    )):
        return Decimal("85.00")

    if any(term in normalized_title for term in (
        "software engineer", "software developer",
        "web developer", "web engineer", "programmer",
        "application developer",
    )):
        return Decimal("75.00")

    # Related technical roles, but not the primary target.
    if any(term in normalized_title for term in (
        "frontend", "front end", "ui developer",
        "devops", "qa engineer", "test engineer",
        "data engineer", "data scientist",
    )):
        return Decimal("45.00")

    # General engineering titles shouldn't automatically score 80.
    if any(term in normalized_title for term in (
        "engineer", "developer", "architect",
        "technical lead", "programmer",
    )):
        return Decimal("35.00")

    # Nontechnical or unrelated titles.
    return Decimal("0.00")